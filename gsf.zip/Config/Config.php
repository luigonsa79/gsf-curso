<?php 

const base_url = 'http://localhost/gsf';